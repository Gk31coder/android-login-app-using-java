This is a basic Android application with two screens:

A Login Screen with username and password input

A Welcome Screen that shows the entered username

Features
Simple UI using Material Design

Navigation between activities

Built using Java or Kotlin

How to Run
Clone the repository

Open the project in Android Studio

Run on an emulator or Android device

APK
The APK file is available in the apk/ folder (if included).

Author
Developed by Gayatri