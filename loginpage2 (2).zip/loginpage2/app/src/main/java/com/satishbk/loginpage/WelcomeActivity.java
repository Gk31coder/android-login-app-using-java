package com.satishbk.loginpage;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {
    TextView welcomeText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcomeactivity);

        welcomeText = findViewById(R.id.textw);
        String username = getIntent().getStringExtra("USERNAME");
        welcomeText.setText("Welcome " + username + "!");
    }
}
